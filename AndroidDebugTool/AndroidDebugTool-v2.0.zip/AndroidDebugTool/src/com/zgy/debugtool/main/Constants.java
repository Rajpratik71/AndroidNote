package com.zgy.debugtool.main;


public class Constants {
	public static final String APP_UnShow = "com.android.packageinstaller";
	public static final String APP_ServiceName = "com.zgy.debugtool.showtopinfo.ShowService";
}
